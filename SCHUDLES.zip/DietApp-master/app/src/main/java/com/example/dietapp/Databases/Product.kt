package com.example.dietapp.Databases

data class Product(
    val name: String? = null,
    val calories: String? = null,
    val fat: String? = null,
    val protein: String? = null,
    val carbohydrates: String? = null
) {
}