package com.example.dietapp.Databases

data class Activity(
    val name: String? = null,
    val caloriesBurned: String? = null,
) {
}